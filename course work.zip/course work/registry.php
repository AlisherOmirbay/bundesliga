
<html>
  <head>
    <title>Login Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

  </head>
  <body>

    <header>
      <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand" href="#"><span><img style="width:200px;" src="/icon/bundesliga.svg"></span></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item">
                <a class="nav-link" href="#"><small>BROADCASTERS</small></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"><small>VIRTUAL BUNDESLIGA</small></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"><small>FANTASY MANAGER</small></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"><small>PREDICTION GAME</small></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"><small>DFL</small></a>
              </li>
            </ul>
          </div>
        </div>
    </nav>

    <div class="row" style="background:#c80a00; height:58px;">
        <div class="container">
      <nav class="navbar navbar-expand-xl pt-0">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText1" aria-controls="navbarText1" aria-expanded="false" aria-label="Toggle navigation">
          <span><img src="/icon/admin.png" style="width:23px;"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText1">
          <ul class="list-group list-group-horizontal">
            <li class="list-unstyled"><a class="list-group-item py-3" style="background:#a70b00; color:white;" href="/index.php">Home</a></li>
            <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="/table.php">Table</a></li>
            <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="/clubs.php">Clubs</a></li>
            <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Fixtures& Results</a></li>
            <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Live</a></li>
            <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Legends</a></li>
            <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Stats</a></li>
            <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Awards</a></li>
            <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">FAQ</a></li>
            <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Season 2020/21</a></li>
            <li style="padding-left:50px;"><a class="list-group-item py-3" style="background:#c80a00;" href="/login.php"><span><img src="/icon/admin.png" style="width:23px;"></span></a></li>
          </ul>
        </div>
      </nav>
    </div>
    </div>
    </header>
    <div class="container-fluid pt-3 pb-5" style="background:#e5e5e5;">
      <div class="container mx-auto">
      <div class="row justify-content-center mt-5">
        <div class="col-5">
          <h1>Sign Up</h1>
          <form class="form-group" action="/sign_up.php" method="post">
            <label class="label">Name</label><br>
            <input class="form-control" type="text" name="email" aria-describedby="asd">
            <small class="text-muted" id="asd">Input your name</small><br>
            <label class="label">Surname</label><br>
            <input class="form-control" type="text" name="email">
            <small class="text-muted" id="asd">Input your surname</small><br>
            <label class="label">Phone</label><br>
            <input class="form-control" type="number" name="phone">
            <small class="text-muted" id="asd">Input your number</small><br>
            <label class="label">Email</label><br>
            <input class="form-control" type="email" name="email">
            <small class="text-muted" id="asd">Input your email</small><br>
            <label class="label">Password</label><br>
            <input class="form-control" type="password" name="password"><br>
            <label class="label">Requare Password</label><br>
            <input class="form-control" type="requare" name="requare"><br>
            <input type="checkbox" name="check">
            <label>Remember Me</label><br>
            <div class="d-flex flex-column justify-content center mt-3">
              <button type="submit" class="btn btn-success" >Sign Up</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- footer -->
  <div class="container-fluid py-3">
    <div class="container">
      <div class="row d-flex justify-content-between">
        <a class="pl-3 text-muted" href="#">Advertsing</a>
        <a class="text-muted" href="#">Partner</a>
        <a class="text-muted" href="#">Privacy Statement</a>
        <a class="text-muted" href="#">Jobs</a>
        <a class="text-muted" href="#">Player</a>
        <a class="text-muted" href="#">Legal Notices</a>
        <a class="text-muted" href="#">Terms of Use</a>
        <a class="text-muted" href="#">Coockies Settings</a>
        <a class="pr-3 text-muted" href="#">Contact</a>
      </div>
    </div>
  </div>
  <div class="container-fluid bg-secondary py-3">
    <div class="container">
      <div class="col-3 mx-auto py-5">
          <small> © 2020 DFL Deutsche Fußball Liga GmbH </small>
      </div>
    </div>
  </div>
</body>
</html>

  </body>
</html>
