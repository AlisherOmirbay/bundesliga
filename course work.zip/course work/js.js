function onmouseImgmove(img){
  img.width = 40;
  img.height = 40;
  console.log(img.width+" "+img.height+" move");
}
function onmouseImgover(img){
  img.width = 50;
  img.height = 50;
  console.log(img.width+" "+img.height+" over");
}

function clicked(button){
  window.location.href = 'http://localhost/registry.php';
}
