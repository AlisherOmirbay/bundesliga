<!-- Task 1 -->
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <script src="/js.js" type="text/javascript"></script>
    <title>ClubsPage</title>
</head>
<body>
  <header>
    <div class="container">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#"><span><img style="width:200px;" src="/icon/bundesliga.svg"></span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="#"><small>BROADCASTERS</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>VIRTUAL BUNDESLIGA</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>FANTASY MANAGER</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>PREDICTION GAME</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>DFL</small></a>
            </li>
          </ul>
        </div>
      </div>
  </nav>

  <div class="row" style="background:#c80a00; height:58px;">
      <div class="container">
    <nav class="navbar navbar-expand-xl pt-0">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText1" aria-controls="navbarText1" aria-expanded="false" aria-label="Toggle navigation">
        <span><img src="/icon/admin.png" style="width:23px;"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarText1">
        <ul class="list-group list-group-horizontal">
          <li class="list-unstyled"><a class="list-group-item py-3" style="background:#c80a00; color:white;" href="/index.php">Home</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="/table.php">Table</a></li>
          <li><a class="list-group-item py-3" style="background:#a70b00; color:white; padding:12px;" href="/clubs.php">Clubs</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Fixtures& Results</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Live</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Legends</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Stats</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Awards</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">FAQ</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Season 2020/21</a></li>
          <li style="padding-left:50px;"><a class="list-group-item py-3" style="background:#c80a00;" href="/login.php"><span><img src="/icon/admin.png" style="width:23px;"></span></a></li>
        </ul>
      </div>
    </nav>
  </div>
  </div>
  </header>
  <div class="container-fluid pt-5 pb-5" style="background:#e5e5e5;">
    <div class="container mx-auto">
      <h1 class="text-italic">CLUB OVERVIEW | SEASON 2020-2021</h1>
      <div class="row">
        <div class="col-4">
          <div class="card border-primary mb-3" style="max-width: 18rem;">
            <div class="card-header"><span><img src="icon/fcb.svg" onmousemove="onmouseImgmove(this);" onmouseout="onmouseImgover(this);" style="max-width:50px; max-height:50px;"></span></div>
            <div class="card-body text-primary">
              <h5 class="card-title">Bayern Munchen</h5>
              <p class="card-text">Allianz Arena</p>
            </div>
          </div>
        </div>
        <div class="col-4">
          <div class="card border-secondary mb-3" style="max-width: 18rem;">
            <div class="card-header"><span><img src="icon/b04.svg" onmousemove="onmouseImgmove(this);" onmouseout="onmouseImgover(this);" style="max-width:50px; max-height:50px;"></span></div>
            <div class="card-body text-secondary">
              <h5 class="card-title">Bayer 04 Leverkusen</h5>
              <p class="card-text">BayArena</p>
            </div>
          </div>
        </div>
        <div class="col-4">
          <div class="card border-success mb-3" style="max-width: 18rem;">
            <div class="card-header"><span><img src="icon/bvb.svg" onmousemove="onmouseImgmove(this);" onmouseout="onmouseImgover(this);" style="max-width:50px; max-height:50px;"></span></div>
            <div class="card-body text-success">
              <h5 class="card-title">Borussia Dortmund</h5>
              <p class="card-text">SIGNAL IDUNA PARK</p>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-4">
          <div class="card border-danger mb-3" style="max-width: 18rem;">
            <div class="card-header"><span><img src="icon/rbl.svg" onmousemove="onmouseImgmove(this);" onmouseout="onmouseImgover(this);" style="max-width:50px; max-height:50px;"></span></div>
            <div class="card-body text-danger">
              <h5 class="card-title">RB Leipzig</h5>
              <p class="card-text">Red Bull Arena</p>
            </div>
          </div>
        </div>
        <div class="col-4">
          <div class="card border-warning mb-3" style="max-width: 18rem;">
            <div class="card-header"><span><img src="icon/vfb.svg" onmousemove="onmouseImgmove(this);" onmouseout="onmouseImgover(this);" style="max-width:50px; max-height:50px;"></span></div>
            <div class="card-body text-warning">
              <h5 class="card-title">VfB Stuttgart</h5>
              <p class="card-text">Mercedes-Benz Arena</p>
            </div>
          </div>
        </div>
        <div class="col-4">
          <div class="card border-info mb-3" style="max-width: 18rem;">
            <div class="card-header"><span><img src="icon/svw.svg" onmousemove="onmouseImgmove(this);" onmouseout="onmouseImgover(this);" style="max-width:50px; max-height:50px;"></span></div>
            <div class="card-body text-info">
              <h5 class="card-title">SV Werder Bremen</h5>
              <p class="card-text">wohninvest WESERSTADION</p>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-4">
          <div class="card border-light mb-3" style="max-width: 18rem;">
            <div class="card-header"><span><img src="icon/sge.svg" onmousemove="onmouseImgmove(this);" onmouseout="onmouseImgover(this);" style="max-width:50px; max-height:50px;"></span></div>
            <div class="card-body">
              <h5 class="card-title">Eintracht Frankfurt</h5>
              <p class="card-text">Deutsche Bank Park</p>
            </div>
          </div>
        </div>
        <div class="col-4">
          <div class="card border-dark mb-3" style="max-width: 18rem;">
            <div class="card-header"><span><img src="icon/fcu.svg" onmousemove="onmouseImgmove(this);" onmouseout="onmouseImgover(this);" style="max-width:50px; max-height:50px;"></span></div>
            <div class="card-body text-dark">
              <h5 class="card-title">1. FC Union Berlin</h5>
              <p class="card-text">An der Alten Försterei</p>
            </div>
          </div>
        </div>
        <div class="col-4">
          <div class="card border-primary mb-3" style="max-width: 18rem;">
            <div class="card-header"><span><img src="icon/fca.svg" onmousemove="onmouseImgmove(this);" onmouseout="onmouseImgover(this);" style="max-width:50px; max-height:50px;"></span></div>
            <div class="card-body text-primary">
              <h5 class="card-title">FC Augsburg</h5>
              <p class="card-text">WWK ARENA</p>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

  <!-- footer -->
  <div class="container-fluid py-3">
    <div class="container">
      <div class="row d-flex justify-content-between">
        <a class="pl-3 text-muted" href="#">Advertsing</a>
        <a class="text-muted" href="#">Partner</a>
        <a class="text-muted" href="#">Privacy Statement</a>
        <a class="text-muted" href="#">Jobs</a>
        <a class="text-muted" href="#">Player</a>
        <a class="text-muted" href="#">Legal Notices</a>
        <a class="text-muted" href="#">Terms of Use</a>
        <a class="text-muted" href="#">Coockies Settings</a>
        <a class="pr-3 text-muted" href="#">Contact</a>
      </div>
    </div>
  </div>
  <div class="container-fluid bg-secondary py-3">
    <div class="container">
      <div class="col-3 mx-auto py-5">
          <small> © 2020 DFL Deutsche Fußball Liga GmbH </small>
      </div>
    </div>
  </div>
</body>
</html>
