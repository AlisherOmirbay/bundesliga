
<html>
  <head>
    <title>Login Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

  </head>
  <body>

    <header>
      <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light py-3">
          <a class="navbar-brand" href="#"><span><img style="width:200px;" src="/icon/bundesliga.svg"></span></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item active">
                <h5 class="nav-link text-primary mb-0" href="#">ADMINISTRATION</h5>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/index.php"><small>VIEW SITE</small></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"><small>CHANGE PASSWORD</small></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/login.php"><small>LOGOUT</small></a>
              </li>
            </ul>
          </div>
        </div>
    </nav>
    </header>
    <div class="container-fluid pt-5 pb-5" style="background:#e5e5e5;">
      <div class="container mx-auto">
      <h3 class="text-italic ml-5">Site administration:</h3>
      <div class="col-6">
        <table class="table">
            <thead>
              <tr class="text-center">
                <th colspan="4">Authentication and authorization</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th>1</th>
                <td class="text-left">Users</td>
                <td><a href="#" class="btn btn-primary">+add</td>
                <td><a href="#" class="btn btn-success">edit</td>
              </tr>
              <tr>
              <th>2</th>
                <td>Groups</td>
                <td><a href="#" class="btn btn-primary">+add</td>
                <td><a href="#" class="btn btn-success">edit</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="container-fluid pt-5 pb-5 bg-light">
      <div class="container mx-auto">
      <div class="col-6">
        <table class="table">
            <thead>
              <tr class="text-center">
                <th colspan="4">CATALOG</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th>1</th>
                <td class="text-left">Clubs</td>
                <td><a href="#" class="btn btn-primary">+add</td>
                <td><a href="#" class="btn btn-success">edit</td>
              </tr>
              <tr>
                <th>2</th>
                <td>Leagues</td>
                <td><a href="#" class="btn btn-primary">+add</td>
                <td><a href="#" class="btn btn-success">edit</td>
              </tr>
              <tr>
                <th>3</th>
                <td>News</td>
                <td><a href="#" class="btn btn-primary">+add</td>
                <td><a href="#" class="btn btn-success">edit</td>
              </tr>
              <tr>
                <th>4</th>
                <td>Partners</td>
                <td><a href="#" class="btn btn-primary">+add</td>
                <td><a href="#" class="btn btn-success">edit</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  <!-- footer -->
  <div class="container-fluid py-3">
    <div class="container">
      <div class="row d-flex justify-content-between">
        <a class="pl-3 text-muted" href="#">Advertsing</a>
        <a class="text-muted" href="#">Partner</a>
        <a class="text-muted" href="#">Privacy Statement</a>
        <a class="text-muted" href="#">Jobs</a>
        <a class="text-muted" href="#">Player</a>
        <a class="text-muted" href="#">Legal Notices</a>
        <a class="text-muted" href="#">Terms of Use</a>
        <a class="text-muted" href="#">Coockies Settings</a>
        <a class="pr-3 text-muted" href="#">Contact</a>
      </div>
    </div>
  </div>
  <div class="container-fluid bg-secondary py-3">
    <div class="container">
      <div class="col-3 mx-auto py-5">
          <small> © 2020 DFL Deutsche Fußball Liga GmbH </small>
      </div>
    </div>
  </div>
</body>
</html>

  </body>
</html>
