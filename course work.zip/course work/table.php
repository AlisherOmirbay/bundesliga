<!-- Task 1 -->
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <title>TablePage</title>
</head>
<body>
  <header>
    <div class="container">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#"><span><img style="width:200px;" src="/icon/bundesliga.svg"></span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="#"><small>BROADCASTERS</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>VIRTUAL BUNDESLIGA</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>FANTASY MANAGER</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>PREDICTION GAME</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>DFL</small></a>
            </li>
          </ul>
        </div>
      </div>
  </nav>

  <div class="row" style="background:#c80a00; height:58px;">
      <div class="container">
    <nav class="navbar navbar-expand-xl pt-0">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText1" aria-controls="navbarText1" aria-expanded="false" aria-label="Toggle navigation">
        <span><img src="/icon/admin.png" style="width:23px;"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarText1">
        <ul class="list-group list-group-horizontal">
          <li class="list-unstyled"><a class="list-group-item py-3" style="background:#c80a00; color:white;" href="/index.php">Home</a></li>
          <li><a class="list-group-item py-3" style="background:#a70b00; color:white; padding:12px;" href="/table.php">Table</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="/clubs.php">Clubs</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Fixtures& Results</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Live</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Legends</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Stats</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Awards</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">FAQ</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Season 2020/21</a></li>
          <li style="padding-left:50px;"><a class="list-group-item py-3" style="background:#c80a00;" href="/login.php"><span><img src="/icon/admin.png" style="width:23px;"></span></a></li>
        </ul>
      </div>
    </nav>
  </div>
  </div>
  </header>
  <div class="container-fluid pt-5 pb-5" style="background:#e5e5e5;">
    <div class="container mx-auto">
      <h1 class="text-italic">TABLE | 2020-2021 | MATCHDAY 5</h1>
      <table class="table">
          <thead class="thead-light">
            <tr>
              <th scope="col"></th>
              <th scope="col"></th>
              <th scope="col"></th>
              <th scope="col">Played</th>
              <th scope="col">Points</th>
              <th scope="col">W</th>
              <th scope="col">D</th>
              <th scope="col">L</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">1</th>
              <td><span><img src="/icon/rbl.svg" style="width:30px;"></span></td>
              <td>Leipzig</td>
              <td>4</td>
              <td>10</td>
              <td>3</td>
              <td>1</td>
              <td>0</td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td><span><img src="/icon/fcb.svg" style="width:30px;"></span></td>
              <td>Bayern</td>
              <td>4</td>
              <td>9</td>
              <td>3</td>
              <td>0</td>
              <td>1</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td><span><img src="/icon/bvb.svg" style="width:30px;"></span></td>
              <td>Borussia Dortmund</td>
              <td>4</td>
              <td>9</td>
              <td>2</td>
              <td>2</td>
              <td>0</td>
            </tr>
            <tr>
              <th scope="row">4</th>
              <td><span><img src="/icon/sge.svg" style="width:30px;"></span></td>
              <td>Eintracht Frankfurt</td>
              <td>4</td>
              <td>10</td>
              <td>3</td>
              <td>1</td>
              <td>0</td>
            </tr>
            <tr>
              <th scope="row">5</th>
              <td><span><img src="/icon/vfb.svg" style="width:30px;"></span></td>
              <td>VfB Stuttgart</td>
              <td>4</td>
              <td>9</td>
              <td>3</td>
              <td>0</td>
              <td>1</td>
            </tr>
            <tr>
              <th scope="row">6</th>
              <td><span><img src="/icon/fca.svg" style="width:30px;"></span></td>
              <td>FC Augsburg</td>
              <td>4</td>
              <td>9</td>
              <td>2</td>
              <td>2</td>
              <td>0</td>
            </tr>
            <tr>
              <th scope="row">7</th>
              <td><span><img src="/icon/svw.svg" style="width:30px;"></span></td>
              <td>SV Werder Bremen</td>
              <td>4</td>
              <td>10</td>
              <td>3</td>
              <td>1</td>
              <td>0</td>
            </tr>
            <tr>
              <th scope="row">8</th>
              <td><span><img src="/icon/tsg.svg" style="width:30px;"></span></td>
              <td>TSG Hoffenheim</td>
              <td>4</td>
              <td>9</td>
              <td>3</td>
              <td>0</td>
              <td>1</td>
            </tr>
            <tr>
              <th scope="row">9</th>
              <td><span><img src="/icon/b04.svg" style="width:30px;"></span></td>
              <td>Bayer 04 Leverkusen</td>
              <td>4</td>
              <td>9</td>
              <td>2</td>
              <td>2</td>
              <td>0</td>
            </tr>
            <tr>
              <th scope="row">10</th>
              <td><span><img src="/icon/fcu.svg" style="width:30px;"></span></td>
              <td>FC Union Berlin</td>
              <td>4</td>
              <td>9</td>
              <td>2</td>
              <td>2</td>
              <td>0</td>
            </tr>
          </tbody>
        </table>
    </div>
  </div>


  <!-- footer -->
  <div class="container-fluid py-3">
    <div class="container">
      <div class="row d-flex justify-content-between">
        <a class="pl-3 text-muted" href="#">Advertsing</a>
        <a class="text-muted" href="#">Partner</a>
        <a class="text-muted" href="#">Privacy Statement</a>
        <a class="text-muted" href="#">Jobs</a>
        <a class="text-muted" href="#">Player</a>
        <a class="text-muted" href="#">Legal Notices</a>
        <a class="text-muted" href="#">Terms of Use</a>
        <a class="text-muted" href="#">Coockies Settings</a>
        <a class="pr-3 text-muted" href="#">Contact</a>
      </div>
    </div>
  </div>
  <div class="container-fluid bg-secondary py-3">
    <div class="container">
      <div class="col-3 mx-auto py-5">
          <small> © 2020 DFL Deutsche Fußball Liga GmbH </small>
      </div>
    </div>
  </div>
</body>
</html>
