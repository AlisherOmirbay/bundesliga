<!-- Task 1 -->
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <title>MainPage</title>
</head>
<body>
  <header>
    <div class="container">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#"><span><img style="width:200px;" src="/icon/bundesliga.svg"></span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="#"><small>BROADCASTERS</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>VIRTUAL BUNDESLIGA</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>FANTASY MANAGER</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>PREDICTION GAME</small></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"><small>DFL</small></a>
            </li>
          </ul>
        </div>
      </div>
  </nav>
  <div class="row" style="background:#c80a00; height:58px;">
      <div class="container">
    <nav class="navbar navbar-expand-xl pt-0">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText1" aria-controls="navbarText1" aria-expanded="false" aria-label="Toggle navigation">
        <span><img src="/icon/admin.png" style="width:23px;"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarText1">
        <ul class="list-group list-group-horizontal">
          <li class="list-unstyled"><a class="list-group-item py-3" style="background:#a70b00; color:white;" href="/index.php">Home</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="/table.php">Table</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="/clubs.php">Clubs</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Fixtures& Results</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Live</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Legends</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Stats</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Awards</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">FAQ</a></li>
          <li><a class="list-group-item py-3" style="background:#c80a00; color:white; padding:12px;" href="#">Season 2020/21</a></li>
          <li style="padding-left:50px;"><a class="list-group-item py-3" style="background:#c80a00;" href="/login.php"><span><img src="/icon/admin.png" style="width:23px;"></span></a></li>
        </ul>
      </div>
    </nav>
  </div>
  </div>
  </header>
  <div class="container-fluid pt-5 pb-5" style="background:#e5e5e5;">
    <div class="container">
      <div class="card bg-dark text-white">
        <img src="/images/main.jpg" class="card-img" alt="...">
        <div class="card-img-overlay pt-5" style="margin-top:40%; background:rgba(0,0,0,.6);">
          <h5 class="card-title">Coman shines as Bayern hammer Atletico</h5>
          <p class="card-text">Kingsley Coman scored two and made another as Bayern proved too hot to handle for Atletico Madrid.</p>
          <p class="card-text">8 hours ago</p>
        </div>
      </div>
    </div>
    <!--PARTNERS  -->
    <div class="container mt-3">
      <p class="text-left pl-3">OFFICIAL PARTNERS OF THE BUNDESLIGA</p>
      <ul class="list-group list-group-horizontal d-flex justify-content-between bg-white border">
        <li class="list-group-item border-0"><a href="#"><span><img src="/icon/aws.svg" style="weight:200px; height:50px;"></span></a></li>
        <li class="list-group-item border-0"><a href="#"><span><img src="/icon/derbystar.svg" style="weight:200px; height:50px;"></span></a></li>
        <li class="list-group-item border-0"><a href="#"><span><img src="/icon/ea.svg" style="weight:200px; height:50px;"></span></a></li>
        <li class="list-group-item border-0"><a href="#"><span><img src="/icon/topps.svg" style="weight:200px; height:50px;"></span></a></li>
      </ul>
    </div>
<!-- News -->
    <div class="container mt-3">
      <p class="text-left pl-3">News</p>
      <!-- <ul class="list-group list-group-horizontal d-flex justify-content-between bg-white border"> -->
      <div class="row">
        <div class="col-6">
          <div class="card mb-3">
            <img src="/images/image1.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Late leveller denies Gladbach</h5>
              <p class="card-text">Ramy Bensebaini and Jonas Hofmann were on target for the Foals, who had to settle for their Champions League opener in Italy.</p>
              <p class="card-text"><small class="text-muted">9 hours ago</small></p>
            </div>
          </div>
        </div>
        <div class="col-6">
          <div class="card mb-3">
            <img src="/images/image2.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">"Davies has been recharging" - Hansi Flick</h5>
              <p class="card-text">Bayern's head coach explains why Lucas Hernandez has been used more than Davies at left-back in the early part of 2020/21.</p>
              <p class="card-text"><small class="text-muted">9 hours ago</small></p>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-4">
          <div class="card mb-3">
            <img src="/images/image3.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Leverkusen vs. Nice: team news</h5>
              <p class="card-text">Lucas Alario should lead the line for Leverkusen against Nice, for whom former Bundesliga champion Dante is captain.</p>
              <p class="card-text"><small class="text-muted">9 hours ago</small></p>
            </div>
          </div>
        </div>
        <div class="col-4">
          <div class="card mb-3">
            <img src="/images/image4.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Florian Wirtz, Leverkusen's natural successor to Kai Havertz</h5>
              <p class="card-text">Kai Havertz may have left Leverkusen for Chelsea, but in Florian Wirtz, die Werkself may have a ready-made successor.</p>
              <p class="card-text"><small class="text-muted">9 hours ago</small></p>
            </div>
          </div>
        </div>
        <div class="col-4">
          <div class="card mb-3">
            <img src="/images/image5.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Angelino’s goal was close to world class” – Nagelsmann</h5>
              <p class="card-text">The Leipzig boss was full of praise for his left-winger following his stunning brace in the Champions League.</p>
              <p class="card-text"><small class="text-muted">9 hours ago</small></p>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
  <!-- footer -->
  <div class="container-fluid py-3">
    <div class="container">
      <div class="row d-flex justify-content-between">
        <a class="pl-3 text-muted" href="#">Advertsing</a>
        <a class="text-muted" href="#">Partner</a>
        <a class="text-muted" href="#">Privacy Statement</a>
        <a class="text-muted" href="#">Jobs</a>
        <a class="text-muted" href="#">Player</a>
        <a class="text-muted" href="#">Legal Notices</a>
        <a class="text-muted" href="#">Terms of Use</a>
        <a class="text-muted" href="#">Coockies Settings</a>
        <a class="pr-3 text-muted" href="#">Contact</a>
      </div>
    </div>
  </div>
  <div class="container-fluid bg-secondary py-3">
    <div class="container">
      <div class="col-3 mx-auto py-5">
          <small> © 2020 DFL Deutsche Fußball Liga GmbH </small>
      </div>
    </div>
  </div>
</body>
</html>
